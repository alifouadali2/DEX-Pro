const express = require('express');
const app = express();
const bodyParser = require('body-parser');
app.set('view engine', 'ejs')
const MongoClient = require('mongodb').MongoClient
const connectionString = "mongodb+srv://AliSaleh:DexPass@cluster0.qlsfj.mongodb.net/StoresDB?retryWrites=true&w=majority";
MongoClient.connect(connectionString, { useUnifiedTopology: true })
  .then(client => {
    console.log('Connected to Database')
    const db = client.db('StoresDB')
    const storesCollection = db.collection('store')
    app.use(bodyParser.urlencoded({ extended: true }))
    app.get('/', function (req, res) {
      db.collection('store').find().toArray()
      .then(results => {
        res.render('index.ejs', {store:results})
      })
      .catch(error => console.error(error))  

    })
    app.post('/store', (req, res) => {
      storesCollection.insertOne(req.body)
    .then(result => {
      console.log(result)
    })
    .catch(error => console.error(error))
    })
    app.listen(3000, function () {
      console.log('listening on 3000')
    })
    db.collection("store").find({}).toArray(function(err, result) {
      if (err) throw err;
      console.log( result);
    });
  })
  .catch(error => console.error(error))